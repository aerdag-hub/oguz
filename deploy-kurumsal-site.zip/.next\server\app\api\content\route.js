var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/content/route.js")
R.c("server/chunks/[externals]__0e3yxol._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_1vnq_yt._.js")
R.c("server/chunks/_next-internal_server_app_api_content_route_actions_1cf1ibk.js")
R.m(4129)
module.exports=R.m(4129).exports
